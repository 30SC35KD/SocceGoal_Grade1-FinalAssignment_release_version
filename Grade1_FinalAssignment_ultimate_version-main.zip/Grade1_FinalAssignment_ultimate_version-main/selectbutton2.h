#ifndef SELECTBUTTON2_H
#define SELECTBUTTON2_H
#include<QPushButton>
class selectbutton2:public QPushButton
{
public:
    selectbutton2();
};


#endif // SELECTBUTTON2_H
