#include "aftegoal.h"

aftegoal::aftegoal(QWidget *parent)
    : QWidget{parent}
{}
