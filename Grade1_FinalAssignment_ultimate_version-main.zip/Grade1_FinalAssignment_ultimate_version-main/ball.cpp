#include "ball.h"
#include<QRectF>
ball::ball()
{x=720;
    y=300;
    vx=0;
    vy=0;}
